Color: #2B9DF4

Font: Orbitron, Jura